// uwb_gui: operator console for UWB calibration sessions (CALIB_UWB.md / P1).
//   live ranges from vcom_node (uwb/burst_metadata) + uwb/pos, start/stop bringup and the bag recorder,
//   timed holds at taped spots -> <bag>_spots.txt with (t0, t1, x, y, z) rows that `uwb_calib.py spots` reads
//   directly (no guessing still segments), and one-click analysis.
// Threads: GUI = main thread on its own core; ROS executor on another core; they share only lock-free queues.
// Child processes (ros2 launch / bag record / python) are spawned from the GUI thread, output shown in "Log".
#include "rt.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_stdlib.h"
#include "implot.h"
#ifdef GUI_HEADLESS
#include "imgui_impl_null.h"
#else
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <GLFW/glfw3.h>
#endif
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <nlohmann/json.hpp>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <algorithm>
#include <cmath>
#include <csignal>
#include <cstring>
#include <ctime>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <sys/wait.h>
#include <thread>
#include <unistd.h>
#include <vector>

constexpr int kN = 8;                         // anchors 1..8 -> index 0..7
constexpr float kNaN = std::numeric_limits<float>::quiet_NaN();
constexpr double kTrimS = 3.0;                // cut from both ends of a hold: covers bag-start offset + settling
const std::string kDir = DRONE_DIR;

static volatile std::sig_atomic_t g_quit = 0;   // Ctrl+C in the terminal -> leave the loop, stop children cleanly
static double now_s() { timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return double(ts.tv_sec) + double(ts.tv_nsec) * 1e-9; }

// ---------------------------------------------------------------- messages (POD, SI) ----------
struct Quality {
  bool present = false;
  float age_ms = kNaN, fp = kNaN, rx = kNaN, anchor_fp = kNaN, anchor_rx = kNaN;
  std::uint16_t f1=0, f2=0, f3=0, cir=0, rxpacc=0, noise=0, fp_index=0;
  std::int32_t carrier=0;
};
struct Burst {
  double rx_s; std::uint32_t cycle_seq; std::uint64_t tag_us; std::uint16_t boot_id = 0;
  float range_m[kN], fp_dbm[kN], rx_dbm[kN], nlos_db[kN], ci_ppm[kN];
  float temperature=kNaN, vbat=kNaN, env_age_ms=kNaN;
  Quality quality[kN];
};
struct Pos   { double rx_s; float x, y, z, sx, sy, sz; };

static float number(const nlohmann::json& j, const char* key) {
  const auto it = j.find(key);
  return it != j.end() && it->is_number() ? it->get<float>() : kNaN;
}

static bool parse_burst(const std::string& s, Burst& b) {
  b = Burst{}; b.rx_s = now_s();
  for (auto* values : {b.range_m,b.fp_dbm,b.rx_dbm,b.nlos_db,b.ci_ppm})
    std::fill_n(values,kN,kNaN);
  try {
    const auto j = nlohmann::json::parse(s);
    b.cycle_seq=j.at("cycle_seq").get<std::uint32_t>();
    b.tag_us=j.at("tag_time_us").get<std::uint64_t>();
    b.boot_id=j.value("boot_id",std::uint16_t(0));
    b.temperature=number(j,"temperature_c"); b.vbat=number(j,"vbat_v");
    b.env_age_ms=number(j,"env_age_ms");
    for (const auto& a : j.at("anchors")) {
      const int i=a.at("anchor_id").get<int>()-1;
      if (i<0 || i>=kN) continue;
      b.range_m[i]=number(a,"range_mm")/1000.f;
      b.fp_dbm[i]=number(a,"fp_dbm"); b.rx_dbm[i]=number(a,"rx_dbm");
      b.nlos_db[i]=number(a,"nlos_db"); b.ci_ppm[i]=number(a,"ci_ppm");
      const auto it=a.find("quality");
      if (it!=a.end() && it->is_object()) {
        const auto& q=*it; auto& out=b.quality[i];
        out.age_ms=number(q,"age_ms");
        out.present=q.value("resp_valid",false) && out.age_ms<=500.f;
        out.fp=number(q,"fp_dbm"); out.rx=number(q,"rx_dbm");
        out.anchor_fp=number(q,"anchor_fp_dbm"); out.anchor_rx=number(q,"anchor_rx_dbm");
        if (out.present) {
          out.f1=q.at("fp_ampl1").get<std::uint16_t>(); out.f2=q.at("fp_ampl2").get<std::uint16_t>();
          out.f3=q.at("fp_ampl3").get<std::uint16_t>(); out.cir=q.at("cir_pwr").get<std::uint16_t>();
          out.rxpacc=q.at("rxpacc").get<std::uint16_t>(); out.noise=q.at("std_noise").get<std::uint16_t>();
          out.fp_index=q.at("fp_index").get<std::uint16_t>(); out.carrier=q.at("carrier_integrator").get<std::int32_t>();
        }
      }
    }
    return true;
  } catch (const nlohmann::json::exception&) { return false; }
}

struct Links {
  rt::SpscQueue<Burst> burst{1 << 13};          // ~37 s at 220 Hz of slack
  rt::Latest<Pos> pos;
  std::atomic<int> bad_json{0};
};

// ---------------------------------------------------------------- ROS side --------------------
class Bridge : public rclcpp::Node {
 public:
  explicit Bridge(Links& L) : Node("uwb_gui"), L_(L) {
    sb_ = create_subscription<std_msgs::msg::String>("uwb/burst_metadata", 200,
      [this](std_msgs::msg::String::ConstSharedPtr m) { onBurst(m->data); });
    sp_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>("uwb/pos", 10,
      [this](geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr m) {
        const auto& p = m->pose.pose.position; const auto& c = m->pose.covariance;
        L_.pos.write({now_s(), float(p.x), float(p.y), float(p.z),
                      float(std::sqrt(c[0])), float(std::sqrt(c[7])), float(std::sqrt(c[14]))});
      });
  }
 private:
  void onBurst(const std::string& s) {
    Burst b;
    if (!parse_burst(s,b)) { L_.bad_json.fetch_add(1); return; }
    L_.burst.try_push(b);
  }
  Links& L_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sb_;
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr sp_;
};

// ---------------------------------------------------------------- child processes -------------
struct LogBuf {
  std::vector<std::string> lines;
  void add(std::string s) { if (lines.size() > 4000) lines.erase(lines.begin(), lines.begin() + 1000); lines.push_back(std::move(s)); }
};

struct Proc {
  explicit Proc(const char* n) : name(n) {}
  const char* name;
  pid_t pid = -1; int fd = -1, exit_code = 0; std::string part;

  bool running() const { return pid > 0; }
  void start(const std::vector<std::string>& args, LogBuf& log) {
    std::vector<char*> av;                      // built before fork: the child only calls async-signal-safe functions
    for (auto& a : args) av.push_back(const_cast<char*>(a.c_str()));
    av.push_back(nullptr);
    std::string cmd = "$"; for (auto& a : args) cmd += " " + a;
    log.add(std::string("[") + name + "] " + cmd);
    int p[2];
    if (pipe2(p, O_CLOEXEC) != 0) { log.add("pipe failed"); return; }
    pid = fork();
    if (pid == 0) {
      setpgid(0, 0);                            // own group: SIGINT reaches launch's children too
      dup2(p[1], 1); dup2(p[1], 2);
      execvp(av[0], av.data());
      _exit(127);
    }
    close(p[1]);
    if (pid < 0) { close(p[0]); log.add("fork failed"); return; }
    setpgid(pid, pid);                          // also from the parent: no race with an early stop()
    fd = p[0]; fcntl(fd, F_SETFL, O_NONBLOCK);
  }
  void stop() const { if (pid > 0) kill(-pid, SIGINT); }   // SIGINT: bag recorder closes the file cleanly
  void poll(LogBuf& log) {
    if (fd >= 0) {
      char buf[4096]; ssize_t n;
      while ((n = read(fd, buf, sizeof buf)) > 0) {
        part.append(buf, size_t(n));
        for (size_t k; (k = part.find('\n')) != std::string::npos; part.erase(0, k + 1))
          log.add(std::string("[") + name + "] " + part.substr(0, k));
      }
    }
    int st;
    if (pid > 0 && waitpid(pid, &st, WNOHANG) == pid) {
      exit_code = WIFEXITED(st) ? WEXITSTATUS(st) : 128 + WTERMSIG(st);
      log.add(std::string("[") + name + "] exited " + std::to_string(exit_code));
      pid = -1;
      if (fd >= 0) { close(fd); fd = -1; }
    }
  }
};

// ---------------------------------------------------------------- GUI state -------------------
struct Scrolling {
  std::vector<float> x, y; int cap, n = 0, off = 0;
  explicit Scrolling(int c) : x(c), y(c), cap(c) {}
  void push(float px, float py) {
    if (n < cap) { x[n] = px; y[n] = py; ++n; } else { x[off] = px; y[off] = py; off = (off + 1) % cap; }
  }
  // median of y over x in [a, b); NaN if empty
  float median(float a, float b, std::vector<float>& tmp) const {
    tmp.clear();
    for (int k = 0; k < n; ++k) if (x[k] >= a && x[k] < b && !std::isnan(y[k])) tmp.push_back(y[k]);
    if (tmp.empty()) return kNaN;
    std::nth_element(tmp.begin(), tmp.begin() + long(tmp.size() / 2), tmp.end());
    return tmp[tmp.size() / 2];
  }
};

struct Spot { float p[3]; double t0 = 0, t1 = 0; bool done = false; };

struct Ui {
  Links& L;
  LogBuf log;
  Proc bringup{"bringup"}, rec{"record"}, calib{"calib"};
  // live
  std::vector<Scrolling> r = std::vector<Scrolling>(kN, Scrolling(8192));
  Pos pos{}; double t0 = now_s(), last_rx = -1; float t_latest = 0;
  float fp_last[kN]{}, rx_last[kN]{}, nlos_last[kN]{}, ci_last[kN]{};
  float temperature=kNaN, vbat=kNaN, env_age_ms=kNaN;
  Quality quality[kN];
  float hz = 0, ok_pct[kN]{}; int n_sec = 0, ok_sec[kN]{}; double sec_start = now_s();
  std::uint32_t last_cycle = 0; std::uint64_t last_tag_us = 0; std::uint16_t boot_id=0;
  bool have_cycle = false; std::uint64_t lost = 0, bursts = 0;
  bool still = false; std::vector<float> tmp;
  float window_s = 20;
  // session
  std::string port = "/dev/ttyACM0", anchors = kDir + "/anchors_rig40.txt", name = "spots", plan = "";
  std::string bag, spots_file;
  bool ref_set = false; std::uint64_t ref_us = 0;      // full 64-bit POLL time
  double rec_started = 0;
  std::vector<Spot> spots; int cur = 0; float hold_s = 60;
  bool holding = false; double hold_t0 = 0;

  explicit Ui(Links& l) : L(l) {
    for (auto* values : {fp_last,rx_last,nlos_last,ci_last}) std::fill_n(values,kN,kNaN);
  }
  bool stale() const { return last_rx < 0 || now_s() - last_rx > 0.5; }
  double tag_rel() const { return last_tag_us>=ref_us ? double(last_tag_us-ref_us)*1e-6 : 0; }

  void ingest() {
    Burst b; int budget = 8192;
    while (budget-- && L.burst.try_pop(b)) {
      last_rx = b.rx_s; ++bursts;
      if (have_cycle && b.boot_id!=boot_id) {
        have_cycle=false; ref_set=false; holding=false;
        log.add("[link] TAG restarted; hold aborted and time reference reset");
      }
      boot_id=b.boot_id;
      if (have_cycle && b.cycle_seq > last_cycle + 1 && b.cycle_seq - last_cycle < 100000) lost += b.cycle_seq - last_cycle - 1;
      last_cycle = b.cycle_seq; have_cycle = true; last_tag_us = b.tag_us;
      if (rec.running() && !ref_set) { ref_set = true; ref_us = b.tag_us; }
      t_latest = float(b.rx_s - t0);
      temperature=b.temperature; vbat=b.vbat; env_age_ms=b.env_age_ms;
      ++n_sec;
      for (int i = 0; i < kN; ++i) {
        r[i].push(t_latest, b.range_m[i]);
        if (!std::isnan(b.range_m[i])) ++ok_sec[i];
        fp_last[i]=b.fp_dbm[i]; rx_last[i]=b.rx_dbm[i];
        nlos_last[i]=b.nlos_db[i]; ci_last[i]=b.ci_ppm[i]; quality[i]=b.quality[i];
      }
    }
    L.pos.read(pos);
    if (const double n = now_s(); n - sec_start >= 1.0) {
      hz = float(n_sec / (n - sec_start));
      for (int i = 0; i < kN; ++i) ok_pct[i] = n_sec ? 100.f * float(ok_sec[i]) / float(n_sec) : 0.f;
      n_sec = 0; std::fill_n(ok_sec, kN, 0); sec_start = n;
      // same test as uwb_calib.still_segments: 75th pct of |Δ per-second median| over anchors < 1 cm
      std::vector<float> d;
      for (int i = 0; i < kN; ++i) {
        const float a = r[i].median(t_latest - 2, t_latest - 1, tmp), c = r[i].median(t_latest - 1, t_latest + 1, tmp);
        if (!std::isnan(a) && !std::isnan(c)) d.push_back(std::fabs(c - a));
      }
      std::sort(d.begin(), d.end());
      still = d.size() >= 4 && d[size_t(0.75 * double(d.size() - 1))] < 0.01f;
    }
    bringup.poll(log); rec.poll(log); calib.poll(log);
    if (holding && (!rec.running() || stale())) { holding = false; log.add("[spots] hold aborted: recorder stopped or link stale"); }
    if (holding && tag_rel() - hold_t0 >= hold_s) finish_hold();
  }

  // ---- actions
  void start_bringup() {
    bringup.start({"ros2", "launch", kDir + "/bringup.launch.py", "camera:=false", "vslam:=false", "fc:=false",
                   "uwb:=true", "uwb_port:=" + port, "anchors:=" + anchors}, log);
  }
  void start_uart() {
    bringup.start({"/usr/bin/python3",UART_BRIDGE,"--port",port,"--baud","460800"},log);
  }
  void start_record() {
    char ts[32]; const std::time_t t = std::time(nullptr); std::strftime(ts, sizeof ts, "%m%d_%H%M%S", std::localtime(&t));
    bag = std::string(std::getenv("HOME")) + "/bags/" + name + "_" + ts;
    spots_file = bag + "_spots.txt";
    std::filesystem::create_directories(std::string(std::getenv("HOME")) + "/bags");
    ref_set = false; rec_started = now_s();
    for (auto& s : spots) s.done = false;
    cur = 0;
    rec.start({"ros2", "bag", "record", "-s", "mcap", "-o", bag, "/uwb/burst_metadata", "/uwb/pos", "/tf_static"}, log);
  }
  void start_hold() { holding = true; hold_t0 = tag_rel(); log.add("[spots] hold spot " + std::to_string(cur + 1)); }
  void finish_hold() {
    holding = false;
    Spot& s = spots[size_t(cur)];
    s.t0 = hold_t0 + kTrimS; s.t1 = tag_rel() - kTrimS; s.done = true;
    write_spots();
    log.add("[spots] spot " + std::to_string(cur + 1) + " done");
    for (int k = 1; k <= int(spots.size()); ++k)            // next spot not done yet
      if (!spots[size_t((cur + k) % int(spots.size()))].done) { cur = (cur + k) % int(spots.size()); break; }
  }
  void write_spots() const {                                // rewritten on every hold: a crash loses nothing
    std::ofstream f(spots_file);
    f << "# t0_s, t1_s (tag time from the bag's first burst), x, y, z (anchor frame, m) -- written by uwb_gui\n";
    for (const auto& s : spots)
      if (s.done) f << s.t0 << ", " << s.t1 << ", " << s.p[0] << ", " << s.p[1] << ", " << s.p[2] << "\n";
  }
  void load_plan() {
    std::ifstream f(plan);
    if (!f) { log.add("[spots] cannot open " + plan); return; }
    spots.clear(); cur = 0;
    for (std::string ln; std::getline(f, ln);) {
      if (ln.empty() || ln[0] == '#') continue;
      std::replace(ln.begin(), ln.end(), ',', ' ');
      Spot s; std::istringstream is(ln);
      if (is >> s.p[0] >> s.p[1] >> s.p[2]) spots.push_back(s);
    }
    log.add("[spots] loaded " + std::to_string(spots.size()) + " spots from " + plan);
  }
  void analyse(const char* mode) {
    std::vector<std::string> a{"/usr/bin/python3", kDir + "/uwb_calib.py", mode, bag};
    if (!std::strcmp(mode, "spots")) { a.push_back(spots_file); a.push_back(anchors); }
    calib.start(a, log);
  }
};

// ---------------------------------------------------------------- panels ----------------------
static const ImVec4 kOk(0.3f, 0.85f, 0.4f, 1), kBad(0.95f, 0.3f, 0.3f, 1), kWarn(0.95f, 0.75f, 0.2f, 1);

static void proc_row(const char* label, Proc& p) {
  ImGui::TextColored(p.running() ? kOk : ImVec4(0.6f, 0.6f, 0.6f, 1), "%s: %s", label,
                     p.running() ? "running" : (p.exit_code ? "stopped (error)" : "stopped"));
}

static void panel_session(Ui& ui) {
  if (!ImGui::Begin("Session")) { ImGui::End(); return; }
  ImGui::SeparatorText("1. UWB bring-up");
  ImGui::BeginDisabled(ui.bringup.running());
  ImGui::InputText("tag port", &ui.port);
  ImGui::InputText("anchors file", &ui.anchors);
  ImGui::EndDisabled();
  if (!ui.bringup.running()) {
    if (ImGui::Button("Start vcom_node + uwb_pos")) ui.start_bringup();
    ImGui::SameLine();
    ImGui::BeginDisabled(!std::filesystem::exists(UART_BRIDGE));
    if (ImGui::Button("Start UART telemetry")) ui.start_uart();
    ImGui::EndDisabled();
  }
  else if (ImGui::Button("Stop bring-up")) ui.bringup.stop();
  ImGui::SameLine(); proc_row("", ui.bringup);

  ImGui::SeparatorText("2. Record");
  ImGui::BeginDisabled(ui.rec.running());
  ImGui::InputText("name", &ui.name);
  ImGui::EndDisabled();
  if (!ui.rec.running()) {
    ImGui::BeginDisabled(ui.stale());                 // recording with no data = an empty bag
    if (ImGui::Button("Start recording")) ui.start_record();
    ImGui::EndDisabled();
    if (ui.stale()) { ImGui::SameLine(); ImGui::TextColored(kBad, "no bursts"); }
  } else {
    if (ImGui::Button("Stop recording")) { ui.holding = false; ui.rec.stop(); }
    ImGui::SameLine(); ImGui::TextColored(kBad, "REC %.0f s", now_s() - ui.rec_started);
  }
  if (!ui.bag.empty()) ImGui::TextWrapped("bag: %s", ui.bag.c_str());

  ImGui::SeparatorText("3. Analyse (after stopping)");
  ImGui::BeginDisabled(ui.rec.running() || ui.calib.running() || ui.bag.empty());
  if (ImGui::Button("uwb_calib spots")) ui.analyse("spots");
  ImGui::SameLine();
  if (ImGui::Button("uwb_calib warmup")) ui.analyse("warmup");
  ImGui::EndDisabled();
  ImGui::TextDisabled("output -> Log");
  ImGui::End();
}

static void panel_spots(Ui& ui) {
  if (!ImGui::Begin("Spots")) { ImGui::End(); return; }
  ImGui::InputText("plan (x,y,z per line)", &ui.plan); ImGui::SameLine();
  ImGui::BeginDisabled(ui.holding);
  if (ImGui::Button("Load")) ui.load_plan();
  ImGui::SameLine(); if (ImGui::Button("+ spot")) ui.spots.push_back({});
  ImGui::EndDisabled();
  ImGui::SetNextItemWidth(120);
  ImGui::DragFloat("hold [s]", &ui.hold_s, 1, 2 * float(kTrimS) + 5, 600, "%.0f", ImGuiSliderFlags_AlwaysClamp);
  ImGui::SameLine();
  ImGui::TextColored(ui.still ? kOk : kWarn, ui.still ? "tag STILL" : "tag MOVING");

  if (ui.holding) {
    const float left = ui.hold_s - float(ui.tag_rel() - ui.hold_t0);
    ImGui::ProgressBar(1.0f - left / ui.hold_s, ImVec2(-FLT_MIN, 0), nullptr);
    ImGui::TextColored(kWarn, "Holding spot %d: %.0f s left. Stay clear of the tag.", ui.cur + 1, left);
    if (ImGui::Button("Abort hold")) { ui.holding = false; ui.log.add("[spots] hold aborted"); }
  } else {
    ImGui::BeginDisabled(!ui.rec.running() || !ui.ref_set || ui.stale() || ui.spots.empty());
    char lbl[64]; std::snprintf(lbl, sizeof lbl, "Hold spot %d  (Enter)", ui.cur + 1);
    if (ImGui::Button(lbl, ImVec2(-FLT_MIN, ImGui::GetFrameHeight() * 2)) ||
        (ImGui::IsKeyPressed(ImGuiKey_Enter, false) && !ImGui::GetIO().WantTextInput && !ImGui::IsAnyItemActive()))
      if (!ui.spots.empty()) ui.start_hold();
    ImGui::EndDisabled();
  }

  if (ImGui::BeginTable("spots", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_BordersInnerH)) {
    ImGui::TableSetupColumn("#", ImGuiTableColumnFlags_WidthFixed, 24);
    ImGui::TableSetupColumn("x [m]"); ImGui::TableSetupColumn("y [m]"); ImGui::TableSetupColumn("z [m]");
    ImGui::TableSetupColumn("window [s]"); ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 110);
    ImGui::TableHeadersRow();
    int del = -1;
    for (int k = 0; k < int(ui.spots.size()); ++k) {
      Spot& s = ui.spots[size_t(k)];
      ImGui::PushID(k);
      ImGui::TableNextRow();
      if (k == ui.cur) ImGui::TableSetBgColor(ImGuiTableBgTarget_RowBg0, IM_COL32(60, 60, 120, 255));
      ImGui::TableNextColumn(); ImGui::Text("%d", k + 1);
      ImGui::BeginDisabled(ui.holding);
      for (int c = 0; c < 3; ++c) {
        ImGui::TableNextColumn(); ImGui::SetNextItemWidth(-FLT_MIN);
        ImGui::PushID(c); ImGui::DragFloat("##p", &s.p[c], 0.005f, -50, 50, "%.3f"); ImGui::PopID();
      }
      ImGui::TableNextColumn();
      if (s.done) ImGui::TextColored(kOk, "%.0f-%.0f", s.t0, s.t1); else ImGui::TextDisabled("-");
      ImGui::TableNextColumn();
      if (ImGui::SmallButton("select")) ui.cur = k;
      ImGui::SameLine();
      if (s.done ? ImGui::SmallButton("redo") : ImGui::SmallButton("x")) {
        if (s.done) { s.done = false; ui.cur = k; ui.write_spots(); } else del = k;
      }
      ImGui::EndDisabled();
      ImGui::PopID();
    }
    if (del >= 0) { ui.spots.erase(ui.spots.begin() + del); ui.cur = std::min(ui.cur, std::max(0, int(ui.spots.size()) - 1)); }
    ImGui::EndTable();
  }
  ImGui::End();
}

static void panel_link(Ui& ui) {
  if (!ImGui::Begin("Link")) { ImGui::End(); return; }
  ImGui::TextColored(ui.stale() ? kBad : kOk, ui.stale() ? "LINK STALE" : "LINK OK");
  ImGui::SameLine(); ImGui::Text("| %.0f bursts/s | lost cycles %llu | bad json %d | gui drop %llu", ui.hz,
                                 (unsigned long long)ui.lost, ui.L.bad_json.load(), (unsigned long long)ui.L.burst.dropped());
  if (std::isfinite(ui.temperature)) ImGui::Text("TAG %.2f C",ui.temperature);
  else ImGui::TextDisabled("TAG temperature: -");
  ImGui::SameLine();
  if (std::isfinite(ui.vbat)) ImGui::Text("| %.3f V",ui.vbat);
  else ImGui::TextDisabled("| supply: -");
  ImGui::SameLine();
  if (std::isfinite(ui.env_age_ms)) ImGui::Text("| environment age %.0f ms%s",ui.env_age_ms,
      ui.env_age_ms>2500 ? " [stale]" : "");
  else ImGui::TextDisabled("| environment age: -");
  if (ImGui::BeginTable("anchors", 8, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchSame)) {
    ImGui::TableSetupColumn("anchor"); ImGui::TableSetupColumn("range [m]");
    ImGui::TableSetupColumn("answered [%]"); ImGui::TableSetupColumn("fp [dBm]"); ImGui::TableSetupColumn("1 s spread [cm]");
    ImGui::TableSetupColumn("RX [dBm]"); ImGui::TableSetupColumn("RX-FP [dB]"); ImGui::TableSetupColumn("CI [ppm]");
    ImGui::TableHeadersRow();
    for (int i = 0; i < kN; ++i) {
      const Scrolling& s = ui.r[size_t(i)];
      const float last = s.n ? s.y[size_t((s.off + s.n - 1) % s.cap)] : kNaN;
      float lo = 1e9f, hi = -1e9f;
      for (int k = 0; k < s.n; ++k) if (s.x[k] > ui.t_latest - 1 && !std::isnan(s.y[k])) { lo = std::min(lo, s.y[k]); hi = std::max(hi, s.y[k]); }
      ImGui::TableNextRow();
      ImGui::TableNextColumn(); ImGui::Text("%d", i + 1);
      ImGui::TableNextColumn(); if (std::isnan(last)) ImGui::TextColored(kBad, "timeout"); else ImGui::Text("%.3f", last);
      ImGui::TableNextColumn(); ImGui::TextColored(ui.ok_pct[i] > 95 ? kOk : ui.ok_pct[i] > 70 ? kWarn : kBad, "%.0f", ui.ok_pct[i]);
      ImGui::TableNextColumn(); if (std::isnan(ui.fp_last[i])) ImGui::TextDisabled("-"); else ImGui::Text("%.1f", ui.fp_last[i]);
      ImGui::TableNextColumn(); if (hi >= lo) ImGui::Text("%.1f", 100 * (hi - lo)); else ImGui::TextDisabled("-");
      for (const float value : {ui.rx_last[i],ui.nlos_last[i],ui.ci_last[i]}) {
        ImGui::TableNextColumn(); if (std::isnan(value)) ImGui::TextDisabled("-"); else ImGui::Text("%.2f",value);
      }
    }
    ImGui::EndTable();
  }
  if (ImGui::TreeNode("Raw RESP quality (sampled 10 Hz; same-cycle ID/time in JSON)")) {
    if (ImGui::BeginTable("raw_quality",14,ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollX)) {
      for (const char* name : {"A","F1","F2","F3","CIR_PWR","RXPACC","Noise","FP index",
                              "CI raw","FP precise","RX precise","Anchor FP","Anchor RX","Age ms"})
        ImGui::TableSetupColumn(name,ImGuiTableColumnFlags_WidthFixed,85);
      ImGui::TableHeadersRow();
      for (int i=0;i<kN;i++) {
        const auto& q=ui.quality[i];
        ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::Text("%d",i+1);
        for (const auto value : {q.f1,q.f2,q.f3,q.cir,q.rxpacc,q.noise,q.fp_index}) {
          ImGui::TableNextColumn(); if (q.present && !ui.stale()) ImGui::Text("%u",unsigned(value)); else ImGui::TextDisabled("-");
        }
        ImGui::TableNextColumn(); if (q.present && !ui.stale()) ImGui::Text("%d",q.carrier); else ImGui::TextDisabled("-");
        for (const float value : {q.fp,q.rx,q.anchor_fp,q.anchor_rx,q.age_ms}) {
          ImGui::TableNextColumn(); if (q.present && !ui.stale() && !std::isnan(value)) ImGui::Text("%.2f",value); else ImGui::TextDisabled("-");
        }
      }
      ImGui::EndTable();
    }
    ImGui::TreePop();
  }
  const bool pos_fresh = now_s() - ui.pos.rx_s < 0.5;
  ImGui::TextColored(pos_fresh ? kOk : ImVec4(0.6f, 0.6f, 0.6f, 1), "uwb/pos  x %.3f  y %.3f  z %.3f m   (1σ %.0f %.0f %.0f cm)%s",
                     ui.pos.x, ui.pos.y, ui.pos.z, 100 * ui.pos.sx, 100 * ui.pos.sy, 100 * ui.pos.sz, pos_fresh ? "" : "  [stale]");
  ImGui::End();
}

static void panel_plot(Ui& ui) {
  if (!ImGui::Begin("Ranges")) { ImGui::End(); return; }
  ImGui::SetNextItemWidth(160); ImGui::SliderFloat("window [s]", &ui.window_s, 2, 35, "%.0f");
  if (ImPlot::BeginPlot("##ranges", ImVec2(-1, -1))) {
    ImPlot::SetupAxes("t [s]", "range [m]", 0, ImPlotAxisFlags_AutoFit);
    ImPlot::SetupAxisLimits(ImAxis_X1, ui.t_latest - ui.window_s, ui.t_latest, ImPlotCond_Always);
    for (int i = 0; i < kN; ++i) {
      char id[8]; std::snprintf(id, sizeof id, "a%d", i + 1);
      const Scrolling& s = ui.r[size_t(i)];
      ImPlot::PlotLine(id, s.x.data(), s.y.data(), s.n, ImPlotSpec(ImPlotProp_Offset, s.off));
    }
    ImPlot::EndPlot();
  }
  ImGui::End();
}

static void panel_log(Ui& ui) {
  if (!ImGui::Begin("Log")) { ImGui::End(); return; }
  if (ImGui::SmallButton("clear")) ui.log.lines.clear();
  ImGui::BeginChild("##log", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_HorizontalScrollbar);
  ImGuiListClipper clip; clip.Begin(int(ui.log.lines.size()));
  while (clip.Step())
    for (int k = clip.DisplayStart; k < clip.DisplayEnd; ++k) ImGui::TextUnformatted(ui.log.lines[size_t(k)].c_str());
  if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) ImGui::SetScrollHereY(1.0f);   // follow tail unless scrolled up
  ImGui::EndChild();
  ImGui::End();
}

static void draw_ui(Ui& ui) {
  const ImGuiID dock = ImGui::DockSpaceOverViewport();
  static bool built = false;
  if (!built) { built = true;
    if (ImGui::DockBuilderGetNode(dock) == nullptr || ImGui::DockBuilderGetNode(dock)->IsLeafNode()) {
      ImGui::DockBuilderRemoveNode(dock);
      ImGui::DockBuilderAddNode(dock, ImGuiDockNodeFlags_DockSpace);
      ImGui::DockBuilderSetNodeSize(dock, ImGui::GetMainViewport()->Size);
      ImGuiID left, right, left_bot, right_top, right_bot;
      ImGui::DockBuilderSplitNode(dock, ImGuiDir_Left, 0.38f, &left, &right);
      ImGui::DockBuilderSplitNode(left, ImGuiDir_Down, 0.55f, &left_bot, &left);
      ImGui::DockBuilderSplitNode(right, ImGuiDir_Down, 0.30f, &right_bot, &right_top);
      ImGuiID rt_top, rt_bot;
      ImGui::DockBuilderSplitNode(right_top, ImGuiDir_Up, 0.45f, &rt_top, &rt_bot);
      ImGui::DockBuilderDockWindow("Session", left);
      ImGui::DockBuilderDockWindow("Spots", left_bot);
      ImGui::DockBuilderDockWindow("Link", rt_top);
      ImGui::DockBuilderDockWindow("Ranges", rt_bot);
      ImGui::DockBuilderDockWindow("Log", right_bot);
      ImGui::DockBuilderFinish(dock);
    }
  }
  panel_session(ui); panel_spots(ui); panel_link(ui); panel_plot(ui); panel_log(ui);
}

#ifdef GUI_HEADLESS
// Scripted session for the smoke test: record, hold every planned spot, stop, run uwb_calib spots, quit.
static bool headless_step(Ui& ui, int f) {
  static int phase = 0;
  static bool moved = true;                       // like the operator: hold once the tag has been carried and set down
  if (!ui.still) moved = true;
  if (phase == 0 && f > 30 && !ui.stale()) { ui.start_record(); phase = 1; }
  else if (phase == 1 && ui.ref_set && !ui.holding && ui.tag_rel() > 2) {
    if (std::all_of(ui.spots.begin(), ui.spots.end(), [](auto& s) { return s.done; })) { ui.rec.stop(); phase = 2; }
    else if (ui.still && moved) { ui.start_hold(); moved = false; }
  }
  else if (phase == 2 && !ui.rec.running()) { ui.analyse("spots"); phase = 3; }
  else if (phase == 3 && !ui.calib.running()) return false;
  return true;
}
#endif

// ---------------------------------------------------------------- main = GUI thread -----------
int main(int argc, char** argv) {
  if (argc>1 && !std::strcmp(argv[1],"--self-test")) {
    Burst b;
    if (!parse_burst(R"({"cycle_seq":2,"boot_id":3,"tag_time_us":987654321012,"anchors":[{"anchor_id":1,"range_mm":1234,"fp_dbm":-84.5}]})",b)
        || b.tag_us!=987654321012ULL || b.boot_id!=3 || b.range_m[0]!=1.234f
        || !std::isnan(b.rx_dbm[0]) || b.quality[0].present) return 2;
    if (!parse_burst(R"({"cycle_seq":3,"tag_time_us":987654322012,"temperature_c":34.4,"vbat_v":3.3,"anchors":[{"anchor_id":1,"range_mm":1234,"fp_dbm":-84.5,"rx_dbm":-76.2,"nlos_db":8.3,"ci_ppm":-20.25,"quality":{"resp_valid":true,"age_ms":25,"fp_ampl1":11,"fp_ampl2":22,"fp_ampl3":33,"cir_pwr":44,"rxpacc":63,"std_noise":5,"fp_index":100,"carrier_integrator":35000,"fp_dbm":-84.41,"rx_dbm":-76.22,"anchor_fp_dbm":null,"anchor_rx_dbm":null}}]})",b)
        || !b.quality[0].present || b.quality[0].f1!=11 || b.ci_ppm[0]!=-20.25f
        || std::isnan(b.temperature) || !std::isnan(b.quality[0].anchor_fp)) return 3;
    if (parse_burst("{broken",b)) return 4;
    if (argc>2) {
      std::ifstream input(argv[2]); std::ostringstream buffer; buffer<<input.rdbuf();
      if (!input || !parse_burst(buffer.str(),b) || !b.quality[0].present
          || b.quality[0].f1!=101 || b.tag_us<=0xFFFFFFFFULL) return 5;
      std::puts("Actual C encoder -> ROS JSON -> ImGui parser PASS");
    }
    std::puts("ImGui calibration JSON self-test PASS (legacy + quality/env + 64-bit time + missing values)");
    return 0;
  }
  const int ncpu = int(std::thread::hardware_concurrency());
  int gui_core = ncpu - 1, ros_core = ncpu > 1 ? ncpu - 2 : 0;
  std::string plan; float hold_s = 60;
  for (int i = 1; i + 1 < argc; i += 2) {
    if (!std::strcmp(argv[i], "--gui-core")) gui_core = std::atoi(argv[i + 1]);
    if (!std::strcmp(argv[i], "--ros-core")) ros_core = std::atoi(argv[i + 1]);
    if (!std::strcmp(argv[i], "--plan")) plan = argv[i + 1];
    if (!std::strcmp(argv[i], "--hold")) hold_s = float(std::atof(argv[i + 1]));
  }
  // Pin BEFORE glfwInit: driver threads inherit the mask and stay on the GUI core
  rt::name_this_thread("gui");
  if (!rt::pin_this_thread(gui_core)) std::fprintf(stderr, "warn: cannot pin GUI to core %d\n", gui_core);
  std::signal(SIGPIPE, SIG_IGN);
  std::signal(SIGINT, [](int) { g_quit = 1; });
  std::signal(SIGTERM, [](int) { g_quit = 1; });

  rclcpp::init(argc, argv, rclcpp::InitOptions(), rclcpp::SignalHandlerOptions::None);
  Links L;
  auto node = std::make_shared<Bridge>(L);
  std::thread ros([&] {
    rt::name_this_thread("ros"); rt::pin_this_thread(ros_core);
    rclcpp::executors::SingleThreadedExecutor ex;     // one callback thread = one producer per queue
    ex.add_node(node); ex.spin();
  });

  IMGUI_CHECKVERSION();
  ImGui::CreateContext(); ImPlot::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.ConfigFlags |= ImGuiConfigFlags_DockingEnable | ImGuiConfigFlags_NavEnableKeyboard;
  ImGui::StyleColorsDark();
#ifdef GUI_HEADLESS
  ImGui_ImplNullPlatform_Init(); ImGui_ImplNullRender_Init();
#else
  if (!glfwInit()) return 1;
  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
  const float scale = ImGui_ImplGlfw_GetContentScaleForMonitor(glfwGetPrimaryMonitor());
  GLFWwindow* win = glfwCreateWindow(int(1500 * scale), int(900 * scale), "UWB calibration console", nullptr, nullptr);
  if (!win) return 1;
  glfwMakeContextCurrent(win);
  glfwSwapInterval(1);
  ImGui::GetStyle().ScaleAllSizes(scale); ImGui::GetStyle().FontScaleDpi = scale;
  ImGui_ImplGlfw_InitForOpenGL(win, true); ImGui_ImplOpenGL3_Init("#version 330");
#endif

  Ui ui{L};
  ui.hold_s = hold_s;
  if (!plan.empty()) { ui.plan = plan; ui.load_plan(); }
  for (int f = 0; !g_quit; ++f) {
#ifdef GUI_HEADLESS
    std::this_thread::sleep_for(std::chrono::milliseconds(16));
    ImGui_ImplNullPlatform_NewFrame(); ImGui_ImplNullRender_NewFrame();
    if (!headless_step(ui, f) || f > 60 * 600) break;
#else
    glfwPollEvents();
    if (glfwWindowShouldClose(win)) break;
    if (glfwGetWindowAttrib(win, GLFW_ICONIFIED)) { ui.ingest(); ImGui_ImplGlfw_Sleep(50); continue; }
    ImGui_ImplOpenGL3_NewFrame(); ImGui_ImplGlfw_NewFrame();
#endif
    ui.ingest();
    ImGui::NewFrame();
    draw_ui(ui);
    ImGui::Render();
#ifndef GUI_HEADLESS
    int w, h; glfwGetFramebufferSize(win, &w, &h);
    glViewport(0, 0, w, h); glClearColor(0.08f, 0.08f, 0.09f, 1); glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    glfwSwapBuffers(win);
#endif
  }
#ifdef GUI_HEADLESS
  for (auto& l : ui.log.lines) std::printf("%s\n", l.c_str());
  std::printf("headless: bursts=%llu lost=%llu gui_core=%d bag=%s\n", (unsigned long long)ui.bursts,
              (unsigned long long)ui.lost, rt::current_core(), ui.bag.c_str());
#endif
  // Stop children with SIGINT and wait: a recorder killed hard leaves an unreadable bag
  for (Proc* p : {&ui.rec, &ui.calib, &ui.bringup}) p->stop();
  for (int k = 0; k < 100 && (ui.rec.running() || ui.calib.running() || ui.bringup.running()); ++k) {
    for (Proc* p : {&ui.rec, &ui.calib, &ui.bringup}) p->poll(ui.log);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
  rclcpp::shutdown(); ros.join();
#ifdef GUI_HEADLESS
  ImGui_ImplNullRender_Shutdown(); ImGui_ImplNullPlatform_Shutdown();
#else
  ImGui_ImplOpenGL3_Shutdown(); ImGui_ImplGlfw_Shutdown();
#endif
  ImPlot::DestroyContext(); ImGui::DestroyContext();
#ifndef GUI_HEADLESS
  glfwDestroyWindow(win); glfwTerminate();
#endif
  return 0;
}
