# CALIB_UWB — mô hình bias và nhiễu của range DS-TWR

Mô hình cần tìm cho mỗi anchor *i*:

```
r_i = ‖p − a_i‖ + b_i + d_i(t) + g_i(góc, công suất) + n_i      n_i ~ N(0, σ_i²), cộng outlier NLOS
       hình học    bias   trôi khi   phụ thuộc hướng tag /        nhiễu trắng
                   hằng   ấm lên     tầm gần
```

`uwb_calib.py` đo từng thành phần bằng **một bài đo riêng**. `uwb_pos.py` đọc kết quả (`anN_bias`, `anN_sigma`)
từ file anchors.

## Đã biết từ bag `uwb_20261003_200619` (23 phút, chưa calib antenna delay)

| Thành phần | Số đo | Ghi chú |
|---|---|---|
| `b_i` (bias hằng) | **−13 … +14 cm** tuỳ anchor | Lớn nhất. Firmware báo `status 0x20 = CAL_MISSING`, tức chưa trừ antenna delay |
| `d_i` (trôi) | ≤ 1.1 cm trong 23 phút. Đoạn đứng yên 8.3 phút: lệch 2–2.7 cm ở **phút đầu** (anchor 1, 6, 7), sau đó phẳng | Không biết bag có bắt đầu từ lúc lạnh không |
| Liên hệ với thạch anh | Anchor 8: `ci` trôi 0.26 ppm nhưng range đổi **0.0 cm**. Anchor 6, 7: range đổi 2–2.7 cm nhưng `ci` **không đổi** | Range trôi **không** đi theo thạch anh |
| `σ_i` (trắng, 4.5 ms) | 1.6 – 4.3 cm | Allan giảm theo 1/√τ |
| Bias instability | 0.06 – 0.3 cm (Allan, 1 s → 60 s) | Không thấy random walk |
| `g_i` theo công suất | **Chưa đo được**: `fp_dbm` luôn ≈ −84 dBm, dao động 0.1–0.2 dB | Firmware không gửi công suất thật |

### Vì sao thạch anh nóng lên không làm range dài ra (với DS-TWR)

Tag chạy **DS-TWR** (`mode 0x20`). Công thức DS-TWR bất đối xứng triệt tiêu sai số clock offset ở bậc 1:
sai số còn lại tỉ lệ với ToF × ppm, cỡ ns × 10⁻⁶, tức không đáng kể. Nếu là **SS-TWR** thì khác hẳn: sai số
≈ ½·c·ε·T_reply, khoảng 7.5 cm cho mỗi ppm khi T_reply = 0.5 ms. Data khớp với lý thuyết: `ci` trôi mà range đứng yên.

Nhiệt độ vẫn có thể đổi **delay analog** của mạch RF/anten. Delay đó mới đúng là "antenna delay" và nó không đi
qua `ci`. Phần lệch 2–3 cm ở phút đầu có thể là do nhiệt, nhưng cũng có thể do người vừa đặt tag còn đứng
gần (đổi multipath). Bài 1 tách được hai nguyên nhân này.

---

## Bài 1 — Warm-up từ lạnh: đo `d_i(t)` và mô hình nhiễu

1. Tắt **cả tag lẫn 8 anchor ≥ 1 giờ** để chúng nguội về nhiệt độ phòng.
2. Đặt tag lên giá cố định, giữa giàn (độ cao 117 cm), anten hướng như khi dùng thật.
3. Bật nguồn tất cả **cùng lúc**, ghi **ngay**: `ros2 launch real_data/uwb_record.launch.py`.
4. **Rời phòng, hoặc đứng xa ngoài giàn**, không đi lại trong **60 phút**. Người đi lại sẽ đổi multipath và lẫn vào phép đo nhiệt.
5. Phân tích:

```bash
python3 uwb_calib.py warmup real_data/uwb_<ngày_giờ>
```

| Dòng in ra | Đọc thế nào |
|---|---|
| `bias at minute 0 vs warmed up` | Độ trôi khi ấm lên. Bài này không cần biết vị trí tag: tag đứng yên thì range trừ giá trị lúc đã ấm **chính là** độ trôi |
| `settled after (min)` | Sau bao lâu bias nằm trong 1 cm quanh giá trị cuối, tức thời gian phải warm-up |
| `crystal moved` / `range per ppm` | Range có đi theo `ci` không. Theo lý thuyết DS-TWR là không |
| `Allan dev` | τ = 4.5 ms cho σ trắng; đoạn phẳng là bias instability; đoạn dốc lên (nếu có) là trôi kiểu random walk |

**Quyết định:**
- Trôi < 1 cm: mô hình bias hằng là đủ, bỏ qua `d_i`.
- Trôi > 1 cm nhưng ổn định sau N phút: **warm-up N phút** trước khi dùng. Đơn giản nhất, và không cần code.
- Trôi theo `ci` (cm/ppm ổn định giữa các lần đo): thêm `b_i + k_i·Δci` vào bộ lọc. `ci` có trong mỗi cycle nên sửa online được.
- Trôi theo nhiệt nhưng không theo `ci`: cần nhiệt độ thật. DW1000 có cảm biến nhiệt trên chip
  (`dwt_readtempvbat`), firmware phải gửi nó trong burst.

> **Trên drone sẽ nóng hơn trong lab:** tag nằm gần Jetson và ESC. Nên lặp lại Bài 1 với tag gắn trên rig,
> Jetson chạy tải (cuVSLAM), để có dải nhiệt giống lúc dùng thật.

## Bài 2 — Các điểm đã đo bằng thước: `b_i`, `σ_i`, và `g_i` theo khoảng cách

Làm sau Bài 1 (hệ đã ấm). Đặt tag trên giá tại **≥ 6 điểm đã đo bằng thước** trong khung anchor
(gốc trên sàn dưới anchor 1, x → cột anchor 3, y → cột anchor 4, z hướng lên). Đứng yên **60 s mỗi điểm**,
người đứng ngoài giàn. Mang tag sang điểm kế tiếp mà không dừng giữa đường.

- Chọn điểm **trong giàn và ngoài giàn 1–3 m**, theo nhiều hướng, để thấy bias có đổi theo khoảng cách (công suất) không.
- Thêm **cùng một điểm, xoay tag 0/90/180/270°** (4 dòng `x, y, z` giống nhau) để đo `g_i` theo góc.
  Điều này quan trọng với rig cầm tay, vì tag quay theo người cầm.

`spots.txt`: mỗi điểm một dòng `x, y, z`, **theo đúng thứ tự đặt**. Script tự tìm các đoạn đứng yên
(≥ 30 s) và ghép theo thứ tự, nên không cần ghi giờ.

```bash
python3 uwb_calib.py spots real_data/uwb_<ngày_giờ> spots.txt anchors_rig40.txt
```

| Dòng in ra | Đọc thế nào |
|---|---|
| `bias` | `b_i`. Trung vị của (range − khoảng cách thước) qua các điểm. Đo trực tiếp, không ước lượng vị trí, nên không lẫn với hình học |
| `spread across spots` | Lớn (> 2–3 cm) thì bias đổi theo vị trí hoặc góc: một con số không đủ, xem `g_i` |
| `bias per metre` | Khác 0 thì bias phụ thuộc khoảng cách / công suất |
| `white sigma` | `σ_i` cho bộ lọc |
| `anN_bias / anN_sigma` | Dán vào file anchors, `uwb_pos.py` đọc thẳng |

Nếu số đoạn đứng yên tìm được khác số dòng `spots.txt`, script dừng và in các đoạn nó thấy (theo giây từ đầu bag).

## Bài 3 (tuỳ chọn) — NLOS

Tag đứng yên, một người đi vòng quanh và chen vào giữa tag với từng anchor. Bài này đo tỉ lệ và độ lớn
outlier, để chỉnh `gate` trong `uwb_pos.py` (đang để 5σ).

---

## Firmware cần thêm để đo hết mô hình

| Thiếu | Cho thành phần nào | Lấy từ DW1000 |
|---|---|---|
| Công suất first path / RX thật (`fp_dbm` đang là hằng) | `g_i` theo công suất, phát hiện NLOS (chênh lệch FP và RX) | `dwt_readdiagnostics()`: `firstPathAmp1/2/3`, `rxPreamCount`, `maxGrowthCIR` |
| Nhiệt độ | `d_i` nếu trôi không theo `ci` | `dwt_readtempvbat()` |

## Kiểm lại công cụ

```bash
python3 uwb_calib.py --test   # dữ liệu tổng hợp: tìm lại drift 3 cm / τ 5 phút, cm/ppm, σ, bias ±3 mm, các đoạn đứng yên
python3 uwb_pos.py --test
```
