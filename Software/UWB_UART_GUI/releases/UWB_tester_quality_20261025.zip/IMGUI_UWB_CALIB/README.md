# IMGUI_UWB_CALIB

Dear ImGui + ImPlot operator console for UWB calibration sessions (ROS 2 Humble): live anchor ranges
(`uwb/burst_metadata`, `uwb/pos`), start/stop of bringup and the bag recorder, timed holds at taped spots
-> `<bag>_spots.txt`, one-click `uwb_calib.py` analysis. See `CALIB_UWB.md`.

## Build
```bash
mkdir -p ~/uwb_ws/src && ln -s $PWD/uwb_gui ~/uwb_ws/src/
cd ~/uwb_ws && export PATH=/usr/bin:$PATH   # conda shadows catkin_pkg
colcon build --packages-select uwb_gui \
  --cmake-args -DDRONE_DIR=/path/to/drone_stack   # dir with bringup.launch.py; default = this repo
source install/setup.bash && ros2 run uwb_gui uwb_gui
```
ImGui (v1.92.9b-docking), ImPlot (v1.0), and GLFW (3.4) are pulled in by FetchContent. `-DGUI_HEADLESS=ON` builds a
scripted smoke test that needs no window.

Deps: `rclcpp std_msgs geometry_msgs nlohmann-json-dev`, OpenGL.
