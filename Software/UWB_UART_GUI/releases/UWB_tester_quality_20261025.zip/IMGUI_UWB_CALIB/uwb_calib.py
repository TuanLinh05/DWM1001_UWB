#!/usr/bin/env python3
"""Calibrate the DS-TWR range model: bias per anchor, its drift with warm-up, and the noise. See CALIB_UWB.md.

  python3 uwb_calib.py warmup <bag>                       # tag STILL, from a cold start: drift + Allan deviation
  python3 uwb_calib.py spots <bag> spots.txt [anchors.txt] # tag still at taped points: bias + sigma per anchor
                                                           # spots.txt: one "x, y, z" per point, in visiting order
  python3 uwb_calib.py --test

Both read /uwb/burst_metadata straight from the bag (vcom_node), not the CSV: the CSV drops `ci`, the
crystal offset, which is the only temperature proxy the tag sends.
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SETTLED = 0.01   # m: warm-up is over once every per-minute bias stays within this of its final value


def read_bag(uri):
    """-> t (s, tag clock, from 0), R (m, NaN = timeout), ci (raw, ~ppm*1000), both (N, 8) for anchors 1..8."""
    from rclpy.serialization import deserialize_message
    from rosbag2_py import ConverterOptions, SequentialReader, StorageFilter, StorageOptions
    from std_msgs.msg import String
    r = SequentialReader()
    r.open(StorageOptions(uri=uri, storage_id='mcap'), ConverterOptions('cdr', 'cdr'))
    r.set_filter(StorageFilter(topics=['/uwb/burst_metadata']))
    T, R, C = [], [], []
    while r.has_next():
        b = json.loads(deserialize_message(r.read_next()[1], String).data)
        a = {x['anchor_id']: x for x in b['anchors']}
        T.append(b['tag_time_us'])
        R.append([a[i]['range_mm'] if i in a and a[i]['range_mm'] is not None else np.nan for i in range(1, 9)])
        # New firmware supplies signed CI with explicit ppm units. Prefer
        # the separately timestamped 10 Hz raw sample, then compact 0.25 ppm.
        def ci_value(x):
            q=x.get('quality') or {}
            ppm=q.get('ci_ppm') if q.get('resp_valid') and q.get('age_ms',9999)<=500 else None
            if ppm is None: ppm=x.get('ci_ppm')
            if ppm is not None: return ppm*1000
            legacy=x.get('ci')
            return np.nan if legacy is None else legacy
        C.append([ci_value(a[i]) if i in a else np.nan for i in range(1, 9)])
    t = np.unwrap(np.array(T, float), period=2 ** 32) * 1e-6  # u32 us wraps every 71.6 min
    return t - t[0], np.array(R, float) / 1000, np.array(C, float)


def allan(x, ks):
    """Overlapping Allan deviation of x (NaN interpolated) at averaging lengths ks (samples)."""
    x = x.copy()
    m = np.isnan(x)
    x[m] = np.interp(np.flatnonzero(m), np.flatnonzero(~m), x[~m])
    c = np.r_[0, np.cumsum(x)]
    out = []
    for k in ks:
        a = (c[k:] - c[:-k]) / k
        out.append(np.sqrt(0.5 * np.mean((a[k:] - a[:-k]) ** 2)) if len(a) > k else np.nan)
    return np.array(out)


def warmup(t, R, ci):
    """Tag still the whole time. Geometry is constant, so range minus its own final value IS the bias drift:
    no position is estimated, nothing can soak the drift up."""
    final = t > t[-1] - min(600, t[-1] / 3)  # last 10 min (or last third) = warmed up
    D = R - np.nanmedian(R[final], 0)
    mins = (t // 60).astype(int)
    M = np.array([np.nanmedian(D[mins == k], 0) for k in range(mins.max() + 1)])
    Mci = np.array([np.nanmedian(ci[mins == k], 0) for k in range(mins.max() + 1)])
    bad = np.abs(M) > SETTLED
    settle = np.array([(np.flatnonzero(bad[:, i]).max() + 1) if bad[:, i].any() else 0 for i in range(8)])
    slope = np.array([np.polyfit(Mci[:, i] / 1000, M[:, i], 1)[0] if np.ptp(Mci[:, i]) > 20 else np.nan
                      for i in range(8)])  # m per ppm, only where the crystal actually moved
    dt = np.median(np.diff(t))
    ks = [1, 22, 220, 2200, 13200]  # ~4.5 ms, 0.1 s, 1 s, 10 s, 60 s at 220 Hz
    ad = np.array([allan(R[:, i], ks) for i in range(8)])
    return dict(M=M, Mci=Mci, settle_min=settle, drift=M[0], ppm=np.ptp(Mci, 0) / 1000, m_per_ppm=slope,
                taus=np.array(ks) * dt, adev=ad)


def still_segments(t, R, min_s=30, trim_s=3, step=0.01):
    """Seconds where the per-second median ranges did not move by > step -> runs >= min_s, edges trimmed.
    The tag being carried between points moves every range by cm per second, so the runs are the points."""
    sec = (t // 1).astype(int)
    S = np.unique(sec)
    M = np.array([np.nanmedian(R[sec == k], 0) for k in S])
    # 75th percentile over the 8 anchors: carrying the tag moves several ranges at once, while noise alone
    # pushes one of eight past `step` every few seconds and would chop a still run into pieces
    still = np.r_[False, np.nanpercentile(np.abs(np.diff(M, axis=0)), 75, axis=1) < step]
    runs, k = [], 0
    while k < len(S):
        if still[k]:
            j = k
            while j + 1 < len(S) and still[j + 1] and S[j + 1] == S[j] + 1:
                j += 1
            if S[j] - S[k] + 1 >= min_s:
                runs.append((S[k] + trim_s, S[j] + 1 - trim_s))
            k = j + 1
        else:
            k += 1
    return runs


def spots(t, R, A, truth):
    """truth: rows (x, y, z) in visiting order (still segments found automatically), or (t0, t1, x, y, z),
    tag taped in the anchor frame.
    -> bias (median over spots), spread across spots, white sigma, per-spot table, slope of bias vs distance."""
    truth = np.asarray(truth, float)
    if truth.shape[1] == 3:
        seg = still_segments(t, R)
        if len(seg) != len(truth):
            raise SystemExit(f'found {len(seg)} still segments, spots.txt has {len(truth)} points: '
                             f'{[(round(a), round(b)) for a, b in seg]} (s from the start)')
        truth = np.array([(*g, *p) for g, p in zip(seg, truth)])
    per, dist, white = [], [], []
    for t0, t1, *p in truth:
        s = (t >= t0) & (t < t1)
        d = np.linalg.norm(np.array(p) - A, axis=1)
        e = R[s] - d
        per.append(np.nanmedian(e, 0))
        dist.append(d)
        white.append(e - per[-1])
    per, dist, white = np.array(per), np.array(dist), np.vstack(white)
    slope = np.array([np.polyfit(dist[:, i], per[:, i], 1)[0] if np.ptp(dist[:, i]) > 0.3 else np.nan
                      for i in range(8)])
    return dict(bias=np.median(per, 0), spread=per.std(0), sigma=np.nanstd(white, 0), per_spot=per, dist=dist,
                m_per_m=slope)


def _cm(v):
    return ' '.join(f'{x * 100:6.1f}' for x in v)


def main(a):
    t, R, ci = read_bag(a[1])
    print(f'{len(t)} cycles, {t[-1] / 60:.1f} min, anchors 1..8')
    if a[0] == 'warmup':
        w = warmup(t, R, ci)
        print('bias at minute 0 vs warmed up (cm)', _cm(w['drift']))
        print('settled after (min)               ', ' '.join(f'{x:6d}' for x in w['settle_min']))
        print('crystal moved (ppm)               ', ' '.join(f'{x:6.2f}' for x in w['ppm']))
        print('range per ppm (cm/ppm)            ', _cm(w['m_per_ppm']))
        print('Allan dev (cm) at tau', ' '.join(f'{x:.3f}s' for x in w['taus']))
        for i in range(8):
            print(f'  an{i + 1}', _cm(w['adev'][i]))
        print(f'-> warm up for {w["settle_min"].max()} min before use' if w['settle_min'].any()
              else f'-> no drift above {SETTLED * 100:.0f} cm: a constant bias per anchor is enough')
    else:
        sys.path.insert(0, HERE)
        from uwb_pos import load_anchors
        pos = load_anchors(a[3] if len(a) > 3 else os.path.join(HERE, 'anchors_rig40.txt'))[0]
        A = np.array([pos[i] for i in range(1, 9)])
        s = spots(t, R, A, np.loadtxt(a[2], delimiter=',', ndmin=2))
        print('bias (cm)              ', _cm(s['bias']))
        print('spread across spots (cm)', _cm(s['spread']), '  <- big = bias depends on position/angle, not one number')
        print('bias per metre (cm/m)  ', _cm(s['m_per_m']), '  <- non-zero = distance (power) dependent')
        print('white sigma (cm)       ', _cm(s['sigma']))
        print('\n# paste into the anchors file:')
        for i in range(8):
            print(f'an{i + 1}_bias, {s["bias"][i]:.3f}\nan{i + 1}_sigma, {s["sigma"][i]:.3f}')


def _test():
    rng = np.random.default_rng(1)
    n, dt = int(30 * 60 * 220), 1 / 220
    t = np.arange(n) * dt
    A = np.array([[x, y, z] for z in (0.48, 1.58) for x, y in ((0, 0), (0.4, 0.4), (0.4, 0), (0, 0.4))])
    p = np.array([0.2, 0.2, 1.17])
    drift = np.zeros((n, 8))
    drift[:, 1] = -0.03 * np.exp(-t / 300)  # anchor 2: 3 cm short at power-on, tau 5 min
    ci = np.tile(rng.normal(0, 5000, 8), (n, 1))
    ci[:, 1] += 400 * np.exp(-t / 300)  # its crystal moves with it: 0.4 ppm
    bias = rng.uniform(-0.15, 0.15, 8)
    R = np.linalg.norm(p - A, axis=1) + bias + drift + rng.normal(0, 0.03, (n, 8))
    R[rng.random((n, 8)) < 0.003] = np.nan
    w = warmup(t, R, ci)
    assert abs(w['drift'][1] + 0.027) < 0.005 and np.all(np.abs(np.delete(w['drift'], 1)) < 0.005), w['drift']
    assert 4 <= w['settle_min'][1] <= 7 and np.all(np.delete(w['settle_min'], 1) == 0), w['settle_min']
    assert abs(w['m_per_ppm'][1] + 0.075) < 0.01, w['m_per_ppm']  # -3 cm / 0.4 ppm
    assert np.allclose(w['adev'][:, 0], 0.03, rtol=0.1), w['adev'][:, 0]  # white noise read at tau = 1 cycle
    P = [(0.2, 0.2, 1.17), (1.0, 0.2, 1.0), (0.2, 1.2, 1.3), (-0.8, -0.5, 1.1), (1.5, 1.5, 0.9), (-1, 1, 1.2)]
    tt, RR, t0 = [], [], 0.0
    for k, q in enumerate(P):  # 60 s still at each taped point, then 10 s carried to the next one
        q1 = np.array(P[min(k + 1, len(P) - 1)])
        for dur, path in ((60, lambda u: np.array(q) + 0 * u), (10, lambda u: np.array(q) + u * (q1 - q))):
            tk = t0 + np.arange(int(dur * 220)) * dt
            u = ((tk - t0) / dur)[:, None]
            tt.append(tk)
            RR.append(np.linalg.norm(path(u)[:, None] - A[None], axis=2) + bias + rng.normal(0, 0.03, (len(tk), 8)))
            t0 = tk[-1] + dt
    s = spots(np.concatenate(tt), np.vstack(RR), A, np.array(P))  # visiting order only, no times
    assert np.allclose(s['bias'], bias, atol=0.003) and np.allclose(s['sigma'], 0.03, rtol=0.05), s['bias'] - bias
    assert np.all(np.abs(s['m_per_m']) < 0.005), s['m_per_m']
    print('ok')


if __name__ == '__main__':
    _test() if '--test' in sys.argv else main(sys.argv[1:])
